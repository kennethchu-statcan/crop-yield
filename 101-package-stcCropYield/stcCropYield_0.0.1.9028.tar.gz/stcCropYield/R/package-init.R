#' @importFrom foreach foreach %dopar%
#' @importFrom magrittr %>%
#' @importFrom R6 R6Class
#' @importFrom xgboost xgb.DMatrix xgb.train
NULL
