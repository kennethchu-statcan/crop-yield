library(testthat)
library(stcCropYield)

test_check("stcCropYield")
