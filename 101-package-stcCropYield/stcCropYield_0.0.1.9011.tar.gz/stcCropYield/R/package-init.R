#' @importFrom foreach foreach %dopar%
#' @importFrom magrittr %>%
NULL
